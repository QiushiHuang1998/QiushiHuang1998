---
title: People
permalink: /people/
---

### Principal Investigator

<div class="people-grid">
  <div class="person-card">
    <img src="/assets/img/uploads/pi.jpg" alt="Su‑Huai Wei portrait">
    <div class="meta">
      <strong>Su‑Huai Wei（魏苏淮）</strong><br>
      Dean & Chair Professor, School of Physics, Eastern Institute of Technology (Ningbo)<br>
      <span class="badge">APS Fellow</span> <span class="badge">MRS Fellow</span><br>
      Email: <a href="mailto:suhuaiwei@eitech.edu.cn">suhuaiwei@eitech.edu.cn</a>
    </div>
  </div>
</div>

### Postdoctoral Researchers
<div class="people-grid">
  {% for person in site.people | where: "role", "postdoc" %}
  <div class="person-card">
    <img src="{{ person.photo | default: '/assets/img/uploads/avatar-placeholder.jpg' | relative_url }}" alt="{{ person.title }}">
    <div class="meta">
      <strong>{{ person.title }}</strong><br>
      {{ person.position | default: "Postdoc" }}<br>
      {% if person.email %}Email: <a href="mailto:{{ person.email }}">{{ person.email }}</a>{% endif %}
    </div>
  </div>
  {% endfor %}
</div>

### Graduate Students
<div class="people-grid">
  {% for person in site.people | where: "role", "student" %}
  <div class="person-card">
    <img src="{{ person.photo | default: '/assets/img/uploads/avatar-placeholder.jpg' | relative_url }}" alt="{{ person.title }}">
    <div class="meta">
      <strong>{{ person.title }}</strong><br>
      {{ person.program | default: "PhD/MSc" }}<br>
      {% if person.email %}Email: <a href="mailto:{{ person.email }}">{{ person.email }}</a>{% endif %}
    </div>
  </div>
  {% endfor %}
</div>

### Alumni
<div class="people-grid">
  {% for person in site.people | where: "role", "alumni" %}
  <div class="person-card">
    <img src="{{ person.photo | default: '/assets/img/uploads/avatar-placeholder.jpg' | relative_url }}" alt="{{ person.title }}">
    <div class="meta">
      <strong>{{ person.title }}</strong><br>
      {{ person.degree | default: "" }} {{ person.year | default: "" }} — {{ person.destination | default: "" }}
    </div>
  </div>
  {% endfor %}
</div>

<p class="notice--info">提示：你可以在 <code>admin/</code> 后台直接上传照片并添加/编辑成员；CMS 会自动把图片放进 <code>assets/img/uploads/</code>，并在 <code>_people/</code> 生成/更新条目。</p>
