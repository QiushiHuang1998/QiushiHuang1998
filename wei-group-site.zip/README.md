# Wei Group Website (Jekyll + Minimal Mistakes + Decap CMS)

- 多页结构（Home / People / Research / Publications / News / Teaching / Gallery）
- **支持后台上传照片**（Decap/Netlify CMS）：`/admin` 路由
- 适配 GitHub / Netlify 部署

## 一键部署到 Netlify（推荐：可用后台上传）
1. 把整个仓库推到 GitHub（或直接在 Netlify 连接本 ZIP 解压后的目录）。
2. Netlify 新建站点 → 连接该仓库 → 构建命令留空（Jekyll 不需要），发布目录设为根目录。
3. 在 Netlify 中启用 **Identity** 与 **Git Gateway**（Settings → Identity → Enable identity；Identity → Services → Enable Git Gateway）。
4. 打开 `https://你的域名/admin` 登陆（可开启“邀请用户”）。
5. 上传照片：在 CMS 的 “Gallery” 或 “People” 集合里上传，图片会自动保存到 `assets/img/uploads/`。

> 若使用 GitHub Pages：CMS 仍可使用，但需要配置 GitHub OAuth 应用或改用 Netlify 部署。

## 本地预览
```bash
# 安装 Ruby & Bundler（如已安装可略过）
# macOS: brew install ruby
gem install bundler

# 可直接用系统 Jekyll 构建（Minimal Mistakes 走 remote_theme）
bundle init
bundle add webrick

# 本地预览（无需插件）
bundle exec jekyll serve
# 打开 http://127.0.0.1:4000
```

## 结构
- `index.md` 首页（带头图轮廓与三块 feature）
- `people.md` 人员页（自动读取 `_people/` 集合，支持 CMS 添加成员与头像）
- `publications-list.md` 代表作与近五年 PRL（可继续扩充或改用集合）
- `research.md` 研究方向
- `news.md` 新闻列表（来自 `_posts/`）
- `gallery.md` 照片墙（数据源 `_data/gallery.yml`，通过 CMS 编辑；图片存放于 `assets/img/uploads/`）
- `admin/` CMS 后台（Decap）

## 定制
- 自定义样式在 `assets/css/main.scss`
- 导航与页脚链接在 `_config.yml`
