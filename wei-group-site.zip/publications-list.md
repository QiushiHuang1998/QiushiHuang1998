---
title: Publications
permalink: /publications-list/
---

## Highly‑cited (Top 5)

1. **Special Quasirandom Structures** — A. Zunger, <u>S.-H. Wei</u>, L. G. Ferreira, J. E. Bernard, *Phys. Rev. Lett.* **65**, 353 (1990). [DOI](https://link.aps.org/doi/10.1103/PhysRevLett.65.353)
2. **Electronic Properties of Random Alloys: Special Quasirandom Structures** — <u>S.-H. Wei</u>, L. G. Ferreira, J. E. Bernard, A. Zunger, *Phys. Rev. B* **42**, 9622 (1990). [DOI](https://link.aps.org/doi/10.1103/PhysRevB.42.9622)
3. **Intrinsic n‑type vs p‑type Doping Asymmetry and the Defect Physics of ZnO** — S. B. Zhang, <u>S.-H. Wei</u>, A. Zunger, *Phys. Rev. B* **63**, 075205 (2001). [DOI](https://link.aps.org/doi/10.1103/PhysRevB.63.075205)
4. **Defect Physics of the CuInSe₂ Chalcopyrite Semiconductor** — S. B. Zhang, <u>S.-H. Wei</u>, A. Zunger, H. Katayama‑Yoshida, *Phys. Rev. B* **57**, 9642 (1998). [DOI](https://link.aps.org/doi/10.1103/PhysRevB.57.9642)
5. **Crystal and Electronic Band Structure of Cu₂ZnSnX₄ (X=S,Se)** — S. Chen, X.‑G. Gong, A. Walsh, <u>S.-H. Wei</u>, *Appl. Phys. Lett.* **94**, 041903 (2009). [DOI](https://doi.org/10.1063/1.3074499)

## PRL in the last 5 years

- **Design of Intrinsic Transparent Conductors from a Synergetic Band‑Structure Engineering** — Gui Wang, Xie Zhang, <u>S.-H. Wei</u>, *Phys. Rev. Lett.* **134**, 036401 (2025). [DOI](https://link.aps.org/doi/10.1103/PhysRevLett.134.036401)
- **Nature of Disordering in γ‑Ga₂O₃** — Q.-S. Huang *et al.*, <u>S.-H. Wei</u>, *Phys. Rev. Lett.* **133**, 226101 (2024). [DOI](https://link.aps.org/doi/10.1103/PhysRevLett.133.226101)
- **Origin of Efficiency Enhancement by Lattice Expansion in Hybrid‑Perovskite Solar Cells** — X. Zhang, <u>S.-H. Wei</u>, *Phys. Rev. Lett.* **128**, 136401 (2022). [DOI](https://link.aps.org/doi/10.1103/PhysRevLett.128.136401)

<p class="notice--info">完整论文清单请见 <a href="https://scholar.google.co.th/citations?user=WLN0rVoAAAAJ" target="_blank" rel="noopener">Google Scholar</a>。</p>
