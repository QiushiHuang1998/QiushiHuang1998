---
title: 张三
role: postdoc
position: Postdoctoral Researcher
email: zhangsan@example.com
photo: /assets/img/uploads/zhangsan.jpg
weight: 10
---
研究方向：缺陷与掺杂理论。
