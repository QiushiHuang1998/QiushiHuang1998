---
title: 李四
role: student
program: PhD
email: lisi@example.com
photo: /assets/img/uploads/lisi.jpg
weight: 20
---
研究方向：透明导电材料设计。
