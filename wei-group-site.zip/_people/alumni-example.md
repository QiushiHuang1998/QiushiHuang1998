---
title: 王五
role: alumni
degree: PhD
year: 2024
destination: 某大学助理教授
photo: /assets/img/uploads/wangwu.jpg
weight: 100
---
课题：合金与超晶格。
