---
title: News
permalink: /news/
---

<ul>
  {% for post in site.posts %}
  <li><a href="{{ post.url | relative_url }}">{{ post.title }}</a> <span class="page__meta-date">{{ post.date | date: "%Y-%m-%d" }}</span></li>
  {% endfor %}
</ul>

