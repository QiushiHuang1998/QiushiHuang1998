---
layout: splash
title: Wei Group
header:
  overlay_color: "#0a4ea0"
  overlay_filter: "0.3"
  overlay_image: /assets/img/uploads/hero.jpg
  actions:
    - label: "People"
      url: /people/
    - label: "Publications"
      url: /publications-list/
excerpt: "计算材料与凝聚态理论 · School of Physics, Eastern Institute of Technology (Ningbo)"
feature_row:
  - image_path: /assets/img/uploads/feature-research.jpg
    alt: "Research"
    title: "Research"
    excerpt: "第一性原理电子结构、缺陷与掺杂、合金/超晶格、界面与异质结、光伏与功率电子材料、透明导电。"
    url: "/research/"
    btn_label: "Learn more"
    btn_class: "btn--primary"
  - image_path: /assets/img/uploads/feature-people.jpg
    alt: "People"
    title: "People"
    excerpt: "PI / Postdocs / Graduate Students / Alumni"
    url: "/people/"
    btn_label: "Meet the team"
    btn_class: "btn--primary"
  - image_path: /assets/img/uploads/feature-gallery.jpg
    alt: "Gallery"
    title: "Gallery"
    excerpt: "活动与日常照片，支持后台上传与管理"
    url: "/gallery/"
    btn_label: "View photos"
    btn_class: "btn--primary"
---

{% include feature_row %}

## Welcome

我们致力于用第一性原理与多尺度理论揭示材料的电子结构、缺陷与掺杂机制，并服务于光伏、功率电子与透明导电等应用材料设计。

**PI：魏苏淮（Su‑Huai Wei）** — 院长与讲席教授，东方理工大学（宁波）理学部物理学院；曾任 NREL 理论材料组负责人、CSRC 讲席教授。APS & MRS Fellow。

