---
title: Gallery
permalink: /gallery/
---

<div class="gallery-grid">
  {% for item in site.data.gallery %}
    <a href="{{ item.src | relative_url }}" target="_blank"><img src="{{ item.src | relative_url }}" alt="{{ item.alt | default: 'group photo' }}"></a>
  {% endfor %}
</div>

<p class="notice--info">在后台（/admin）上传照片后，系统会自动把图片放到 <code>assets/img/uploads/</code>，并把路径写入 <code>_data/gallery.yml</code> 里。</p>
